const fs = require("fs")

// fs.open("./../assets/map.txt", 'w', (err, file) => {
//     if (err) {
//         console.log("map.txt 생성에 문제가 있습니다", err)
//         throw err
//     }
//     console.log("saved!")
// })